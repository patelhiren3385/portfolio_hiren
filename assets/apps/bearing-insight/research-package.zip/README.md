# Bearing Insight
Private web research demonstrator, built for Hiren Patel. Synthetic-only six-pattern CNN with browser-local image processing. No real-photo accuracy has been established.

Open `dist/index.html` through a static HTTP server. See `research/MODEL_CARD.md` for scope, research sources, dataset audit, training details and the validation gap. Run `python research/train.py` to reproduce the model and `node research/test-parity.cjs` to check browser/PyTorch equivalence.
