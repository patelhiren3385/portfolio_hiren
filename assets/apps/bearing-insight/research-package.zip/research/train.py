"""Deterministic procedural surface-pattern experiment; NOT a real bearing diagnosis model.
Run: python -m pip install torch numpy pillow; python research/train.py
No published photographs are used. Test data are also synthetic, independent seeds.
"""
import json,random,time,hashlib
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFilter
import torch
from torch import nn
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'dist';OUT.mkdir(exist_ok=True)
CLASSES=['Smooth surface','Scratch / scoring','Pitting-like texture','Corrosion-like texture','Smearing / wiping','Crack-like line']

def render(label,seed):
 r=np.random.default_rng(seed); s=96; yy,xx=np.mgrid[:s,:s];base=r.uniform(90,175)+r.normal(0,4,(s,s))+r.uniform(10,35)*np.sin(xx/s*np.pi+r.uniform(0,2))
 a=np.repeat(base[:,:,None],3,2); a+=r.normal(0,2,(s,1,1));im=Image.fromarray(np.uint8(np.clip(a,0,255)));d=ImageDraw.Draw(im)
 if label==1:
  for _ in range(r.integers(5,22)):
   x,y=r.integers(0,s,2);length=int(r.integers(20,80));v=int(r.integers(35,110));d.line((int(x),int(y),int(x+length),int(y+r.integers(-8,9))),fill=(v,v,v),width=int(r.integers(1,3)))
 if label==2:
  for _ in range(r.integers(16,70)):
   x,y=r.integers(3,s-3,2);rad=int(r.integers(1,5));v=int(r.integers(30,100));d.ellipse((x-rad,y-rad,x+rad,y+rad),fill=(v,v,v));d.arc((x-rad,y-rad,x+rad,y+rad),0,150,fill=(200,200,200))
 if label==3:
  for _ in range(r.integers(35,100)):
   x,y=r.integers(0,s,2);rad=int(r.integers(2,12));d.ellipse((x-rad,y-rad,x+rad,y+rad),fill=(int(r.integers(70,170)),int(r.integers(35,85)),int(r.integers(15,50))))
 if label==4:
  for _ in range(r.integers(4,12)):
   x,y=r.integers(0,s,2);v=int(r.integers(70,210));d.ellipse((x-30,y-3,x+30,y+6),fill=(v,v,int(v*.9)))
  im=im.filter(ImageFilter.GaussianBlur(float(r.uniform(.5,1.5))))
 if label==5:
  x,y=int(r.integers(10,30)),int(r.integers(10,30));pts=[(x,y)]
  for _ in range(7):x+=int(r.integers(3,12));y+=int(r.integers(0,10));pts.append((x,y))
  d.line(pts,fill=(30,30,30),width=int(r.integers(1,3)))
  for x,y in pts[2:5]:d.line((x,y,x-int(r.integers(5,15)),y+int(r.integers(6,15))),fill=(40,40,40),width=1)
 im=im.rotate(int(r.integers(0,360)),resample=Image.Resampling.BILINEAR);im=im.crop((15,15,81,81)).resize((64,64),Image.Resampling.BILINEAR)
 arr=np.asarray(im).astype(float)*r.uniform(.75,1.2)+r.normal(0,r.uniform(0,4),(64,64,3));return np.uint8(np.clip(arr,0,255))

class CNN(nn.Module):
 def __init__(self):
  super().__init__();self.layers=nn.Sequential(nn.Conv2d(3,8,3,padding=1),nn.ReLU(),nn.MaxPool2d(2),nn.Conv2d(8,16,3,padding=1),nn.ReLU(),nn.MaxPool2d(2),nn.Conv2d(16,24,3,padding=1),nn.ReLU(),nn.AdaptiveAvgPool2d(4),nn.Flatten(),nn.Linear(384,6))
 def forward(self,x):return self.layers(x)

def main():
 torch.set_num_threads(4);torch.manual_seed(42);np.random.seed(42)
 def dataset(n,start):
  ys=np.repeat(np.arange(6),n);xs=np.stack([render(int(y),start+i) for i,y in enumerate(ys)]);return torch.tensor(xs.transpose(0,3,1,2).copy(),dtype=torch.float32)/255,torch.tensor(ys)
 x,y=dataset(400,10000);v,vy=dataset(80,100000);t,ty=dataset(100,500000)
 model=CNN();opt=torch.optim.Adam(model.parameters(),lr=.001);best=1e9;history=[]
 for epoch in range(70):
  model.train();losses=[]
  for ids in torch.randperm(len(y)).split(64):
   opt.zero_grad();loss=nn.functional.cross_entropy(model(x[ids]),y[ids]);loss.backward();opt.step();losses.append(loss.item())
  model.eval()
  with torch.no_grad():vl=nn.functional.cross_entropy(model(v),vy).item();acc=(model(v).argmax(1)==vy).float().mean().item()
  history.append({'epoch':epoch+1,'loss':float(np.mean(losses)),'validation_loss':vl,'validation_accuracy':acc})
  if vl<best:best=vl;torch.save(model.state_dict(),ROOT/'research/model.pt')
  print(epoch+1,round(vl,3),round(acc,3),flush=True)
 model.load_state_dict(torch.load(ROOT/'research/model.pt',weights_only=True));model.eval()
 with torch.no_grad():probs=model(t).softmax(1);pred=probs.argmax(1);cm=np.zeros((6,6),int)
 for a,b in zip(ty.numpy(),pred.numpy()):cm[a,b]+=1
 f1=[]
 for i in range(6):f1.append(float(2*cm[i,i]/max(1,cm[i,:].sum()+cm[:,i].sum())))
 metrics={'model':'surface-cnn-v0.1','status':'SYNTHETIC ONLY — no real-image validation','classes':CLASSES,'train_count':2400,'validation_count':480,'test_count':600,'test_accuracy':float((pred==ty).float().mean()),'macro_f1':float(np.mean(f1)),'per_class_f1':f1,'confusion_matrix':cm.tolist(),'history':history,'seed':42,'best_epoch':min(history,key=lambda h:h['validation_loss'])['epoch'],'real_training_images':0,'real_test_images':0,'limitations':['Procedural patterns are simplified and are not photorealistic.','Same-generator held-out results measure software feasibility, not industrial performance.','No bearing detector or validated out-of-distribution detector.','Single dominant pattern only; mixed failures unsupported.','Scores are uncalibrated; root causes cannot be inferred from a photo.']}
 (OUT/'metrics.json').write_text(json.dumps(metrics,indent=2));weights={k:v.detach().tolist() for k,v in model.state_dict().items()};(OUT/'model.json').write_text(json.dumps({'classes':CLASSES,'weights':weights}))
 for i in range(6):Image.fromarray(render(i,300000+i)).save(OUT/f'sample-{i}.png')
 parity=t[0:1]
 with torch.no_grad():expected=model(parity).softmax(1)[0].tolist()
 (ROOT/'research/parity.json').write_text(json.dumps({'input':parity[0].permute(1,2,0).tolist(),'expected':expected}))
 print(json.dumps({k:v for k,v in metrics.items() if k not in ['history','limitations']}),flush=True)
if __name__=='__main__':main()
